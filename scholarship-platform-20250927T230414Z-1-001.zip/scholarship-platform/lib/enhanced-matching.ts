// Enhanced Scholarship Matching Algorithm
// Uses all survey data for comprehensive matching

interface SurveyData {
  // Demographics & Barriers
  incomeLevel: string
  deviceAccess: string
  internetAccess: string
  languageSupport: string
  learningNeeds: string
  location: string
  educationLevel: string
  
  // Academic Profile
  favoriteSubject: string
  difficultClass: string
  academicProject: string
  testScoreReflection: string
  dreamCourse: string
  gpaRange: string
  hasTestScores: string
  satScore: string
  actScore: string
  testScorePreference: string
  
  // Personal & Activities
  freeTimeActivities: string
  mostMeaningfulActivity: string
  summerActivities: string
  leadershipExperience: string
  workExperience: string
  
  // Future Vision & Motivation
  whyCollege: string
  worldProblems: string
  futureVision: string
  potentialMajor: string
  roleModel: string
  
  // Practical Preferences
  geographyPreference: string
  schoolSizePreference: string
  budgetReality: string
  nonNegotiables: string
  
  // Open-ended
  barriers: string
  goals: string
}

interface Scholarship {
  id: string
  title: string
  organization: string
  amount: string
  deadline: string
  description: string
  eligibility: string[]
  type: "need-based" | "merit-based" | "first-gen" | "stem" | "international" | "test-optional"
  matchScore: number
  saved: boolean
  requiresTestScores?: boolean
  minSAT?: number
  minACT?: number
  testOptional?: boolean
  
  // Enhanced matching criteria
  targetMajors?: string[]
  targetInterests?: string[]
  targetCauses?: string[]
  requiresLeadership?: boolean
  targetGeography?: string[]
  targetActivities?: string[]
}

export class EnhancedScholarshipMatcher {
  
  static calculateComprehensiveMatch(student: Partial<SurveyData>, scholarship: Scholarship): number {
    let matchScore = 0
    let maxScore = 0

    // 1. INCLUSIVITY INDEX (Base Barriers) - 30%
    maxScore += 30
    matchScore += this.calculateInclusivityMatch(student, scholarship) * 0.3

    // 2. ACADEMIC ALIGNMENT - 25%
    maxScore += 25
    matchScore += this.calculateAcademicMatch(student, scholarship) * 0.25

    // 3. INTEREST & PASSION ALIGNMENT - 20%
    maxScore += 20
    matchScore += this.calculateInterestMatch(student, scholarship) * 0.20

    // 4. LEADERSHIP & ACTIVITIES ALIGNMENT - 15%
    maxScore += 15
    matchScore += this.calculateActivityMatch(student, scholarship) * 0.15

    // 5. VALUES & CAUSE ALIGNMENT - 10%
    maxScore += 10
    matchScore += this.calculateValuesMatch(student, scholarship) * 0.10

    return Math.round(matchScore)
  }

  private static calculateInclusivityMatch(student: Partial<SurveyData>, scholarship: Scholarship): number {
    let score = 0

    // Financial need alignment
    if (scholarship.type === "need-based") {
      if (student.budgetReality === "need-full-aid") score += 25
      else if (student.budgetReality === "under-10k") score += 20
      else if (student.incomeLevel === "low") score += 15
    }

    // First-generation alignment
    if (scholarship.type === "first-gen") {
      // Infer first-gen from various signals
      if (student.whyCollege?.toLowerCase().includes("first") || 
          student.barriers?.toLowerCase().includes("first") ||
          student.workExperience && student.workExperience.length > 50) {
        score += 20
      }
    }

    // Learning differences alignment
    if (scholarship.eligibility.some(req => req.toLowerCase().includes("learning"))) {
      if (student.learningNeeds && student.learningNeeds !== "none") {
        score += 15
      }
    }

    // Language barriers alignment
    if (scholarship.eligibility.some(req => req.toLowerCase().includes("english"))) {
      if (student.languageSupport === "english-second" || student.languageSupport === "need-translation") {
        score += 15
      }
    }

    // Test-optional preference alignment
    if (scholarship.testOptional && 
        (student.hasTestScores === "no-scores" || student.hasTestScores === "yes-no-use")) {
      score += 10
    }

    return Math.min(score, 100)
  }

  private static calculateAcademicMatch(student: Partial<SurveyData>, scholarship: Scholarship): number {
    let score = 0

    // Test score requirements
    if (scholarship.requiresTestScores && student.hasTestScores === "yes-use-scores") {
      const satScore = parseInt(student.satScore || "0")
      const actScore = parseInt(student.actScore || "0")
      
      if (scholarship.minSAT && satScore >= scholarship.minSAT) score += 30
      if (scholarship.minACT && actScore >= scholarship.minACT) score += 30
    }

    // GPA alignment
    if (scholarship.eligibility.some(req => req.includes("GPA"))) {
      if (student.gpaRange === "3.5-4.0") score += 25
      else if (student.gpaRange === "3.0-3.4") score += 20
      else if (student.gpaRange === "2.5-2.9") score += 15
    }

    // Major alignment
    if (scholarship.targetMajors && student.potentialMajor) {
      const studentMajor = student.potentialMajor.toLowerCase()
      const hasMatch = scholarship.targetMajors.some(major => 
        studentMajor.includes(major.toLowerCase()) || major.toLowerCase().includes(studentMajor)
      )
      if (hasMatch) score += 20
    }

    // STEM alignment
    if (scholarship.type === "stem") {
      const stemKeywords = ["science", "technology", "engineering", "math", "computer", "biology", "chemistry", "physics"]
      const studentInterests = `${student.favoriteSubject} ${student.potentialMajor} ${student.dreamCourse}`.toLowerCase()
      
      if (stemKeywords.some(keyword => studentInterests.includes(keyword))) {
        score += 25
      }
    }

    return Math.min(score, 100)
  }

  private static calculateInterestMatch(student: Partial<SurveyData>, scholarship: Scholarship): number {
    let score = 0

    // Subject interest alignment
    if (scholarship.targetInterests && student.favoriteSubject) {
      const studentSubject = student.favoriteSubject.toLowerCase()
      const hasMatch = scholarship.targetInterests.some(interest => 
        studentSubject.includes(interest.toLowerCase()) || interest.toLowerCase().includes(studentSubject)
      )
      if (hasMatch) score += 30
    }

    // Dream course alignment
    if (student.dreamCourse && scholarship.description) {
      const dreamCourse = student.dreamCourse.toLowerCase()
      const scholarshipDesc = scholarship.description.toLowerCase()
      
      // Simple keyword matching (could be enhanced with NLP)
      const commonWords = dreamCourse.split(' ').filter(word => 
        word.length > 3 && scholarshipDesc.includes(word)
      )
      if (commonWords.length > 0) score += 15
    }

    // Academic project alignment
    if (student.academicProject && scholarship.description) {
      const project = student.academicProject.toLowerCase()
      const scholarshipDesc = scholarship.description.toLowerCase()
      
      const commonWords = project.split(' ').filter(word => 
        word.length > 4 && scholarshipDesc.includes(word)
      )
      if (commonWords.length > 1) score += 10
    }

    return Math.min(score, 100)
  }

  private static calculateActivityMatch(student: Partial<SurveyData>, scholarship: Scholarship): number {
    let score = 0

    // Leadership requirement alignment
    if (scholarship.requiresLeadership && student.leadershipExperience) {
      if (student.leadershipExperience.length > 50) score += 30
    }

    // Activity alignment
    if (scholarship.targetActivities && student.mostMeaningfulActivity) {
      const studentActivity = student.mostMeaningfulActivity.toLowerCase()
      const hasMatch = scholarship.targetActivities.some(activity => 
        studentActivity.includes(activity.toLowerCase()) || activity.toLowerCase().includes(studentActivity)
      )
      if (hasMatch) score += 25
    }

    // Community service alignment
    if (scholarship.eligibility.some(req => req.toLowerCase().includes("community") || req.toLowerCase().includes("service"))) {
      const activities = `${student.freeTimeActivities} ${student.summerActivities} ${student.mostMeaningfulActivity}`.toLowerCase()
      const serviceKeywords = ["volunteer", "community", "service", "help", "mentor", "tutor", "charity"]
      
      if (serviceKeywords.some(keyword => activities.includes(keyword))) {
        score += 20
      }
    }

    // Work experience alignment (shows responsibility)
    if (student.workExperience && student.workExperience.length > 30) {
      score += 10
    }

    return Math.min(score, 100)
  }

  private static calculateValuesMatch(student: Partial<SurveyData>, scholarship: Scholarship): number {
    let score = 0

    // Cause alignment
    if (scholarship.targetCauses && student.worldProblems) {
      const studentCauses = student.worldProblems.toLowerCase()
      const hasMatch = scholarship.targetCauses.some(cause => 
        studentCauses.includes(cause.toLowerCase()) || cause.toLowerCase().includes(studentCauses)
      )
      if (hasMatch) score += 40
    }

    // Mission alignment through role model
    if (student.roleModel && scholarship.description) {
      const roleModel = student.roleModel.toLowerCase()
      const scholarshipDesc = scholarship.description.toLowerCase()
      
      // Look for shared values keywords
      const valueKeywords = ["leadership", "service", "innovation", "justice", "equality", "education", "community"]
      const sharedValues = valueKeywords.filter(value => 
        roleModel.includes(value) && scholarshipDesc.includes(value)
      )
      if (sharedValues.length > 0) score += 20
    }

    // Future vision alignment
    if (student.futureVision && scholarship.description) {
      const vision = student.futureVision.toLowerCase()
      const scholarshipDesc = scholarship.description.toLowerCase()
      
      const visionKeywords = ["help", "change", "impact", "improve", "solve", "create", "build"]
      const alignedVisions = visionKeywords.filter(keyword => 
        vision.includes(keyword) && scholarshipDesc.includes(keyword)
      )
      if (alignedVisions.length > 0) score += 15
    }

    return Math.min(score, 100)
  }

  // Method to filter scholarships based on student preferences
  static filterScholarshipsByPreference(
    scholarships: Scholarship[], 
    student: Partial<SurveyData>
  ): Scholarship[] {
    return scholarships.filter(scholarship => {
      
      // Test score filtering
      if (student.hasTestScores === "no-scores" || student.hasTestScores === "yes-no-use") {
        // Only show test-optional scholarships
        if (scholarship.requiresTestScores && !scholarship.testOptional) {
          return false
        }
      }

      // If student wants to use test scores, check if they meet requirements
      if (student.hasTestScores === "yes-use-scores" && scholarship.requiresTestScores) {
        const satScore = parseInt(student.satScore || "0")
        const actScore = parseInt(student.actScore || "0")
        
        if (scholarship.minSAT && satScore > 0 && satScore < scholarship.minSAT) {
          return false
        }
        if (scholarship.minACT && actScore > 0 && actScore < scholarship.minACT) {
          return false
        }
      }

      // Test score preference filtering
      if (student.testScorePreference === "merit-focus" && 
          scholarship.type !== "merit-based") {
        return false
      }

      return true
    })
  }
}

// Usage example:
// const matchedScholarships = EnhancedScholarshipMatcher.filterScholarshipsByPreference(allScholarships, studentData)
//   .map(scholarship => ({
//     ...scholarship,
//     matchScore: EnhancedScholarshipMatcher.calculateComprehensiveMatch(studentData, scholarship)
//   }))
//   .sort((a, b) => b.matchScore - a.matchScore)
