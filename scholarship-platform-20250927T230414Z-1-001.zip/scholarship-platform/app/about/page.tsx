import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Users, Award, Globe, Target, Lightbulb } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 py-24 space-y-16">
        {/* Hero Section */}
        <div className="text-center space-y-6 max-w-3xl mx-auto">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
            💡 Our Mission
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-balance">
            Breaking Down Barriers to Education
          </h1>
          <p className="text-xl text-muted-foreground text-balance leading-relaxed">
            Pathways connects students with educational opportunities designed for their unique circumstances, 
            ensuring that financial barriers, learning differences, and systemic inequities don't limit potential.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                <Target className="h-6 w-6 text-primary" />
              </div>
              <CardTitle className="text-2xl">Our Mission</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                To democratize access to educational opportunities by creating personalized pathways that recognize 
                and support the diverse experiences of all students, especially those who have been historically 
                underserved by traditional systems.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-accent/20">
            <CardHeader>
              <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
                <Lightbulb className="h-6 w-6 text-accent" />
              </div>
              <CardTitle className="text-2xl">Our Vision</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                A world where every student can access education regardless of their socioeconomic background, 
                learning differences, language barriers, or geographic location. Where diversity is recognized 
                as a strength and inclusion is the default.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* What We Do */}
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">What Makes Us Different</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              We go beyond traditional matching to understand your unique journey and connect you with opportunities 
              designed for students like you.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Heart className="h-8 w-8 text-green-600" />
                </div>
                <CardTitle className="text-xl">Inclusivity-First Approach</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Our Inclusivity Index identifies barriers you face and matches you with opportunities specifically 
                  designed to support students with similar experiences.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <CardTitle className="text-xl">Community-Centered</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Beyond scholarships, we connect you with mentorship networks, peer support groups, and local 
                  organizations that understand your journey.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Globe className="h-8 w-8 text-purple-600" />
                </div>
                <CardTitle className="text-xl">Holistic Support</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  We recognize that educational success requires more than funding - from technology access to 
                  language support to learning accommodations.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Impact Stats */}
        <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-2xl p-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">Our Impact</h2>
            <p className="text-muted-foreground">
              Helping students overcome barriers and achieve their educational goals
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-black text-primary mb-2">10K+</div>
              <div className="text-sm text-muted-foreground">Students Served</div>
            </div>
            <div>
              <div className="text-3xl font-black text-accent mb-2">$50M+</div>
              <div className="text-sm text-muted-foreground">Scholarships Matched</div>
            </div>
            <div>
              <div className="text-3xl font-black text-primary mb-2">500+</div>
              <div className="text-sm text-muted-foreground">Partner Organizations</div>
            </div>
            <div>
              <div className="text-3xl font-black text-accent mb-2">85%</div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </div>
          </div>
        </div>

        {/* Values */}
        <div className="space-y-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                title: "Equity Over Equality",
                description: "We provide different levels of support based on individual needs, not identical treatment."
              },
              {
                title: "Student-Centered Design",
                description: "Every feature is built with the student experience and diverse needs at the center."
              },
              {
                title: "Data Privacy",
                description: "Your personal information is protected and never shared without explicit consent."
              },
              {
                title: "Accessibility First",
                description: "Our platform works for users with different abilities, devices, and internet access."
              },
              {
                title: "Cultural Responsiveness",
                description: "We respect and accommodate different cultural backgrounds and communication styles."
              },
              {
                title: "Continuous Learning",
                description: "We constantly improve our matching algorithms based on user feedback and outcomes."
              }
            ].map((value, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center space-y-6 bg-card rounded-2xl p-8">
          <h2 className="text-2xl font-bold">Ready to Start Your Journey?</h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Take our 2-minute survey to get your Inclusivity Index and discover opportunities designed for you.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/survey" className="inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8 font-medium transition-colors">
              Get Started
            </a>
            <a href="/dashboard" className="inline-flex items-center justify-center rounded-full border border-input bg-background hover:bg-accent hover:text-accent-foreground h-11 px-8 font-medium transition-colors">
              View Sample Results
            </a>
          </div>
        </div>
      </main>
    </div>
  )
}
