"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Navigation } from "@/components/navigation"
import { InclusivityIndexCard } from "@/components/inclusivity-index-card"
import { ScholarshipMatches } from "@/components/scholarship-matches"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, Users, Settings, Share2 } from "lucide-react"

interface SurveyResults {
  inclusivityIndex: number
  incomeLevel: string
  deviceAccess: string
  internetAccess: string
  languageSupport: string
  learningNeeds: string
  gpaRange: string
  location: string
  educationLevel: string
  barriers?: string
  goals?: string
  completedAt: string
}

export default function DashboardPage() {
  const [results, setResults] = useState<SurveyResults | null>(null)
  const [savedCount, setSavedCount] = useState(0)
  const router = useRouter()

  useEffect(() => {
    const savedResults = localStorage.getItem("surveyResults")
    if (savedResults) {
      setResults(JSON.parse(savedResults))
    } else {
      router.push("/survey")
    }
  }, [router])

  const handleSaveScholarship = (scholarshipId: string) => {
    // In a real app, this would save to a database
    const saved = JSON.parse(localStorage.getItem("savedScholarships") || "[]")
    const index = saved.indexOf(scholarshipId)

    if (index > -1) {
      saved.splice(index, 1)
    } else {
      saved.push(scholarshipId)
    }

    localStorage.setItem("savedScholarships", JSON.stringify(saved))
    setSavedCount(saved.length)
  }

  if (!results) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your results...</p>
        </div>
      </div>
    )
  }

  // Calculate breakdown for display
  const breakdown = {
    access: Math.round(results.inclusivityIndex * 0.25),
    financial: Math.round(results.inclusivityIndex * 0.25),
    language: Math.round(results.inclusivityIndex * 0.25),
    academic: Math.round(results.inclusivityIndex * 0.25),
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="container mx-auto px-4 py-24 space-y-8">
        {/* Welcome Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-balance">Your Personalized Education Pathway</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
            Based on your unique profile, we've found opportunities designed specifically for students like you.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">{results?.inclusivityIndex || 0}</div>
              <div className="text-sm text-muted-foreground">Inclusivity Index</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent mb-1">12</div>
              <div className="text-sm text-muted-foreground">Scholarship Matches</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">8</div>
              <div className="text-sm text-muted-foreground">Program Matches</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent mb-1">{savedCount}</div>
              <div className="text-sm text-muted-foreground">Saved Items</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Inclusivity Index */}
          <div className="lg:col-span-1 space-y-6">
            {results && (
              <InclusivityIndexCard
                score={results.inclusivityIndex}
                breakdown={{
                  access: Math.round(results.inclusivityIndex * 0.25),
                  financial: Math.round(results.inclusivityIndex * 0.25),
                  language: Math.round(results.inclusivityIndex * 0.25),
                  academic: Math.round(results.inclusivityIndex * 0.25),
                }}
              />
            )}

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href="/saved">
                  <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                    <BookOpen className="h-4 w-4" />
                    View Saved Items
                  </Button>
                </Link>
                <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                  <Users className="h-4 w-4" />
                  Find Communities
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                  <Settings className="h-4 w-4" />
                  Update Profile
                </Button>
                <Button variant="outline" className="w-full justify-start gap-2 bg-transparent">
                  <Share2 className="h-4 w-4" />
                  Share Results
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Scholarship Matches */}
          <div className="lg:col-span-2">
            <ScholarshipMatches onSave={handleSaveScholarship} />
          </div>
        </div>
      </main>
    </div>
  )
}
