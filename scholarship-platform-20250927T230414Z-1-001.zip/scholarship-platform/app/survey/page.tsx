import { EnhancedSurveyForm } from "@/components/enhanced-survey-form"

export default function SurveyPage() {
  return <EnhancedSurveyForm />
}
