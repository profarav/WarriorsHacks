"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Heart,
  ExternalLink,
  Calendar,
  DollarSign,
  CheckCircle,
  Clock,
  AlertCircle,
  Download,
  Share2,
  Trash2,
} from "lucide-react"

interface SavedItem {
  id: string
  title: string
  organization: string
  amount: string
  deadline: string
  description: string
  type: "scholarship" | "program" | "community"
  status: "saved" | "applied" | "completed"
  savedAt: string
  applicationDeadline?: string
  notes?: string
}

// Mock saved items data
const mockSavedItems: SavedItem[] = [
  {
    id: "1",
    title: "First Generation College Student Scholarship",
    organization: "Education Foundation",
    amount: "$5,000",
    deadline: "March 15, 2025",
    description: "Supporting first-generation college students who demonstrate financial need and academic potential.",
    type: "scholarship",
    status: "applied",
    savedAt: "2025-01-15T10:30:00Z",
    applicationDeadline: "March 15, 2025",
    notes: "Submitted application on Jan 20th. Need to follow up with recommendation letters.",
  },
  {
    id: "2",
    title: "STEM Diversity Scholarship",
    organization: "Tech for All Foundation",
    amount: "$7,500",
    deadline: "April 1, 2025",
    description: "Empowering underrepresented students pursuing STEM degrees with financial support and mentorship.",
    type: "scholarship",
    status: "saved",
    savedAt: "2025-01-10T14:20:00Z",
  },
  {
    id: "3",
    title: "Coding Bootcamp for Underrepresented Students",
    organization: "Code for Change",
    amount: "Free",
    deadline: "February 28, 2025",
    description: "12-week intensive coding bootcamp with job placement assistance.",
    type: "program",
    status: "saved",
    savedAt: "2025-01-12T09:15:00Z",
  },
]

export function SavedOpportunities() {
  const [savedItems, setSavedItems] = useState<SavedItem[]>([])
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    // In a real app, this would fetch from an API
    setSavedItems(mockSavedItems)
  }, [])

  const updateItemStatus = (itemId: string, newStatus: SavedItem["status"]) => {
    setSavedItems((items) => items.map((item) => (item.id === itemId ? { ...item, status: newStatus } : item)))
  }

  const removeItem = (itemId: string) => {
    setSavedItems((items) => items.filter((item) => item.id !== itemId))
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "applied":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "applied":
        return <Clock className="h-4 w-4" />
      case "completed":
        return <CheckCircle className="h-4 w-4" />
      default:
        return <Heart className="h-4 w-4" />
    }
  }

  const getUrgencyColor = (deadline: string) => {
    const deadlineDate = new Date(deadline)
    const today = new Date()
    const daysUntil = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    if (daysUntil <= 7) return "text-red-600"
    if (daysUntil <= 30) return "text-orange-600"
    return "text-muted-foreground"
  }

  const filteredItems = savedItems.filter((item) => {
    if (activeTab === "all") return true
    if (activeTab === "scholarships") return item.type === "scholarship"
    if (activeTab === "programs") return item.type === "program"
    if (activeTab === "communities") return item.type === "community"
    return true
  })

  const stats = {
    total: savedItems.length,
    applied: savedItems.filter((item) => item.status === "applied").length,
    completed: savedItems.filter((item) => item.status === "completed").length,
    totalValue: savedItems
      .filter((item) => item.type === "scholarship" && item.amount !== "Free")
      .reduce((sum, item) => {
        const amount = Number.parseInt(item.amount.replace(/[^0-9]/g, ""))
        return sum + (isNaN(amount) ? 0 : amount)
      }, 0),
  }

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Saved Opportunities</h1>
            <p className="text-muted-foreground">Track your applications and manage your opportunities</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export PDF
            </Button>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <Share2 className="h-4 w-4" />
              Share
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">{stats.total}</div>
              <div className="text-sm text-muted-foreground">Total Saved</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600 mb-1">{stats.applied}</div>
              <div className="text-sm text-muted-foreground">Applied</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">{stats.completed}</div>
              <div className="text-sm text-muted-foreground">Completed</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-accent mb-1">${stats.totalValue.toLocaleString()}</div>
              <div className="text-sm text-muted-foreground">Total Value</div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Overview */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Application Progress</CardTitle>
            <CardDescription>
              You've applied to {stats.applied} scholarships worth ${stats.totalValue.toLocaleString()} total!
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Progress</span>
                <span>
                  {stats.applied} of {stats.total} applications started
                </span>
              </div>
              <Progress value={(stats.applied / Math.max(stats.total, 1)) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="all">All ({savedItems.length})</TabsTrigger>
          <TabsTrigger value="scholarships">
            Scholarships ({savedItems.filter((item) => item.type === "scholarship").length})
          </TabsTrigger>
          <TabsTrigger value="programs">
            Programs ({savedItems.filter((item) => item.type === "program").length})
          </TabsTrigger>
          <TabsTrigger value="communities">
            Communities ({savedItems.filter((item) => item.type === "community").length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="space-y-4">
          {filteredItems.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Heart className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No saved opportunities yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start exploring scholarships and programs to build your collection
                </p>
                <Button>Explore Opportunities</Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filteredItems.map((item) => (
                <Card key={item.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className={`text-xs ${getStatusColor(item.status)}`}>
                            <span className="flex items-center gap-1">
                              {getStatusIcon(item.status)}
                              {item.status}
                            </span>
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {item.type}
                          </Badge>
                          {item.deadline && (
                            <div className={`text-xs flex items-center gap-1 ${getUrgencyColor(item.deadline)}`}>
                              <AlertCircle className="h-3 w-3" />
                              Due {item.deadline}
                            </div>
                          )}
                        </div>
                        <CardTitle className="text-xl text-balance leading-tight">{item.title}</CardTitle>
                        <CardDescription className="text-base">{item.organization}</CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeItem(item.id)}
                        className="shrink-0 text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>

                    {item.notes && (
                      <div className="bg-muted/50 rounded-lg p-3">
                        <h4 className="text-sm font-medium mb-1">Notes</h4>
                        <p className="text-sm text-muted-foreground">{item.notes}</p>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4" />
                          <span className="font-medium">{item.amount}</span>
                        </div>
                        {item.deadline && (
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>Due {item.deadline}</span>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {item.status === "saved" && (
                          <Button size="sm" variant="outline" onClick={() => updateItemStatus(item.id, "applied")}>
                            Mark as Applied
                          </Button>
                        )}
                        {item.status === "applied" && (
                          <Button size="sm" variant="outline" onClick={() => updateItemStatus(item.id, "completed")}>
                            Mark as Completed
                          </Button>
                        )}
                        <Button size="sm" className="gap-2">
                          View Details
                          <ExternalLink className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
