"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Moon, Sun, Type, Volume2, Eye, Palette, User, Bell, Shield, Download, RefreshCw, Trash2 } from "lucide-react"

interface AccessibilitySettings {
  darkMode: boolean
  dyslexiaFont: boolean
  fontSize: number
  highContrast: boolean
  reducedMotion: boolean
  screenReader: boolean
  voiceNavigation: boolean
}

interface NotificationSettings {
  emailNotifications: boolean
  deadlineReminders: boolean
  newOpportunities: boolean
  applicationUpdates: boolean
}

interface ProfileSettings {
  name: string
  email: string
  location: string
  bio: string
  preferredLanguage: string
}

export function SettingsPage() {
  const [accessibility, setAccessibility] = useState<AccessibilitySettings>({
    darkMode: false,
    dyslexiaFont: false,
    fontSize: 16,
    highContrast: false,
    reducedMotion: false,
    screenReader: false,
    voiceNavigation: false,
  })

  const [notifications, setNotifications] = useState<NotificationSettings>({
    emailNotifications: true,
    deadlineReminders: true,
    newOpportunities: false,
    applicationUpdates: true,
  })

  const [profile, setProfile] = useState<ProfileSettings>({
    name: "",
    email: "",
    location: "",
    bio: "",
    preferredLanguage: "en",
  })

  const [isSaving, setIsSaving] = useState(false)

  useEffect(() => {
    // Load settings from localStorage
    const savedAccessibility = localStorage.getItem("accessibilitySettings")
    const savedNotifications = localStorage.getItem("notificationSettings")
    const savedProfile = localStorage.getItem("profileSettings")

    if (savedAccessibility) {
      setAccessibility(JSON.parse(savedAccessibility))
    }
    if (savedNotifications) {
      setNotifications(JSON.parse(savedNotifications))
    }
    if (savedProfile) {
      setProfile(JSON.parse(savedProfile))
    }
  }, [])

  useEffect(() => {
    // Apply accessibility settings to document
    const root = document.documentElement

    if (accessibility.darkMode) {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }

    if (accessibility.dyslexiaFont) {
      root.style.fontFamily = "OpenDyslexic, Arial, sans-serif"
    } else {
      root.style.fontFamily = ""
    }

    root.style.fontSize = `${accessibility.fontSize}px`

    if (accessibility.highContrast) {
      root.classList.add("high-contrast")
    } else {
      root.classList.remove("high-contrast")
    }

    if (accessibility.reducedMotion) {
      root.classList.add("reduce-motion")
    } else {
      root.classList.remove("reduce-motion")
    }
  }, [accessibility])

  const updateAccessibility = (key: keyof AccessibilitySettings, value: any) => {
    const newSettings = { ...accessibility, [key]: value }
    setAccessibility(newSettings)
    localStorage.setItem("accessibilitySettings", JSON.stringify(newSettings))
  }

  const updateNotifications = (key: keyof NotificationSettings, value: boolean) => {
    const newSettings = { ...notifications, [key]: value }
    setNotifications(newSettings)
    localStorage.setItem("notificationSettings", JSON.stringify(newSettings))
  }

  const updateProfile = (key: keyof ProfileSettings, value: string) => {
    const newSettings = { ...profile, [key]: value }
    setProfile(newSettings)
  }

  const saveProfile = async () => {
    setIsSaving(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    localStorage.setItem("profileSettings", JSON.stringify(profile))
    setIsSaving(false)
  }

  const retakeSurvey = () => {
    localStorage.removeItem("surveyResults")
    window.location.href = "/survey"
  }

  const exportData = () => {
    const data = {
      profile,
      accessibility,
      notifications,
      surveyResults: JSON.parse(localStorage.getItem("surveyResults") || "{}"),
      savedScholarships: JSON.parse(localStorage.getItem("savedScholarships") || "[]"),
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "pathways-data.json"
    a.click()
    URL.revokeObjectURL(url)
  }

  const deleteAccount = () => {
    if (confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      localStorage.clear()
      window.location.href = "/"
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Customize your experience and manage your account</p>
      </div>

      {/* Profile Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Profile Information
          </CardTitle>
          <CardDescription>Update your personal information and preferences</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={profile.name}
                onChange={(e) => updateProfile("name", e.target.value)}
                placeholder="Enter your full name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={profile.email}
                onChange={(e) => updateProfile("email", e.target.value)}
                placeholder="Enter your email"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                value={profile.location}
                onChange={(e) => updateProfile("location", e.target.value)}
                placeholder="City, State or Country"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="language">Preferred Language</Label>
              <Select
                value={profile.preferredLanguage}
                onValueChange={(value) => updateProfile("preferredLanguage", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="zh">中文</SelectItem>
                  <SelectItem value="ar">العربية</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Bio (Optional)</Label>
            <Textarea
              id="bio"
              value={profile.bio}
              onChange={(e) => updateProfile("bio", e.target.value)}
              placeholder="Tell us about yourself, your goals, or anything you'd like to share..."
              className="min-h-20"
            />
          </div>

          <Button onClick={saveProfile} disabled={isSaving}>
            {isSaving ? "Saving..." : "Save Profile"}
          </Button>
        </CardContent>
      </Card>

      {/* Accessibility Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="h-5 w-5" />
            Accessibility & Display
          </CardTitle>
          <CardDescription>Customize the interface to meet your accessibility needs</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Theme */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                {accessibility.darkMode ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                Dark Mode
              </Label>
              <p className="text-sm text-muted-foreground">Reduce eye strain with a darker color scheme</p>
            </div>
            <Switch
              checked={accessibility.darkMode}
              onCheckedChange={(checked) => updateAccessibility("darkMode", checked)}
            />
          </div>

          <Separator />

          {/* Dyslexia Font */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Type className="h-4 w-4" />
                Dyslexia-Friendly Font
              </Label>
              <p className="text-sm text-muted-foreground">Use OpenDyslexic font for improved readability</p>
            </div>
            <Switch
              checked={accessibility.dyslexiaFont}
              onCheckedChange={(checked) => updateAccessibility("dyslexiaFont", checked)}
            />
          </div>

          <Separator />

          {/* Font Size */}
          <div className="space-y-3">
            <Label>Font Size: {accessibility.fontSize}px</Label>
            <Slider
              value={[accessibility.fontSize]}
              onValueChange={(value) => updateAccessibility("fontSize", value[0])}
              min={12}
              max={24}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Small (12px)</span>
              <span>Large (24px)</span>
            </div>
          </div>

          <Separator />

          {/* High Contrast */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Palette className="h-4 w-4" />
                High Contrast Mode
              </Label>
              <p className="text-sm text-muted-foreground">Increase contrast for better visibility</p>
            </div>
            <Switch
              checked={accessibility.highContrast}
              onCheckedChange={(checked) => updateAccessibility("highContrast", checked)}
            />
          </div>

          <Separator />

          {/* Reduced Motion */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Reduce Motion</Label>
              <p className="text-sm text-muted-foreground">Minimize animations and transitions</p>
            </div>
            <Switch
              checked={accessibility.reducedMotion}
              onCheckedChange={(checked) => updateAccessibility("reducedMotion", checked)}
            />
          </div>

          <Separator />

          {/* Screen Reader */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Screen Reader Optimization</Label>
              <p className="text-sm text-muted-foreground">Enhanced compatibility with screen readers</p>
            </div>
            <Switch
              checked={accessibility.screenReader}
              onCheckedChange={(checked) => updateAccessibility("screenReader", checked)}
            />
          </div>

          <Separator />

          {/* Voice Navigation */}
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label className="flex items-center gap-2">
                <Volume2 className="h-4 w-4" />
                Voice Navigation
              </Label>
              <p className="text-sm text-muted-foreground">Enable voice commands for navigation</p>
              <Badge variant="secondary" className="text-xs">
                Coming Soon
              </Badge>
            </div>
            <Switch
              checked={accessibility.voiceNavigation}
              onCheckedChange={(checked) => updateAccessibility("voiceNavigation", checked)}
              disabled
            />
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Notifications
          </CardTitle>
          <CardDescription>Choose what notifications you'd like to receive</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Email Notifications</Label>
              <p className="text-sm text-muted-foreground">Receive updates via email</p>
            </div>
            <Switch
              checked={notifications.emailNotifications}
              onCheckedChange={(checked) => updateNotifications("emailNotifications", checked)}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Deadline Reminders</Label>
              <p className="text-sm text-muted-foreground">Get notified about upcoming application deadlines</p>
            </div>
            <Switch
              checked={notifications.deadlineReminders}
              onCheckedChange={(checked) => updateNotifications("deadlineReminders", checked)}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>New Opportunities</Label>
              <p className="text-sm text-muted-foreground">Be notified when new scholarships match your profile</p>
            </div>
            <Switch
              checked={notifications.newOpportunities}
              onCheckedChange={(checked) => updateNotifications("newOpportunities", checked)}
            />
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label>Application Updates</Label>
              <p className="text-sm text-muted-foreground">Updates on your scholarship applications</p>
            </div>
            <Switch
              checked={notifications.applicationUpdates}
              onCheckedChange={(checked) => updateNotifications("applicationUpdates", checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Data & Privacy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Data & Privacy
          </CardTitle>
          <CardDescription>Manage your data and privacy settings</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <Button variant="outline" onClick={retakeSurvey} className="gap-2 bg-transparent">
              <RefreshCw className="h-4 w-4" />
              Retake Survey
            </Button>
            <Button variant="outline" onClick={exportData} className="gap-2 bg-transparent">
              <Download className="h-4 w-4" />
              Export My Data
            </Button>
          </div>

          <Separator />

          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-destructive mb-2">Danger Zone</h4>
              <p className="text-sm text-muted-foreground mb-4">
                Once you delete your account, there is no going back. Please be certain.
              </p>
              <Button variant="destructive" onClick={deleteAccount} className="gap-2">
                <Trash2 className="h-4 w-4" />
                Delete Account
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
