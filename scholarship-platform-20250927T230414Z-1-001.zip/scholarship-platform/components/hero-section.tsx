import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { ArrowRight, Users, Award, Globe, Star, TrendingUp, Heart, CheckCircle, Play } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  return (
    <>
      {/* Main Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
        {/* Enhanced Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(120,119,198,0.3),transparent_50%)]" />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(255,107,107,0.2),transparent_40%)]" />
          <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-accent rounded-full animate-pulse" />
          <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-primary rounded-full animate-pulse delay-1000" />
          <div className="absolute bottom-1/4 left-1/3 w-1.5 h-1.5 bg-accent rounded-full animate-pulse delay-500" />
          <div className="absolute bottom-1/3 right-1/4 w-1 h-1 bg-primary rounded-full animate-pulse delay-1500" />
          
          {/* Floating Elements */}
          <div className="absolute top-20 right-20 opacity-20">
            <div className="w-20 h-20 border border-primary/30 rounded-full animate-spin-slow"></div>
          </div>
          <div className="absolute bottom-20 left-20 opacity-20">
            <div className="w-16 h-16 border-2 border-accent/30 rounded-lg rotate-45 animate-bounce-slow"></div>
          </div>
        </div>

        <div className="container mx-auto px-4 text-center relative z-10">
        {/* Main Heading */}
        <div className="max-w-4xl mx-auto mb-12">
          <div className="mb-6">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-medium mb-4">
              ✨ Personalized for your unique journey
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-black tracking-tight text-balance mb-6">
            <span className="block text-foreground">BREAK DOWN</span>
            <span className="block text-accent">BARRIERS</span>
            <span className="block text-foreground">TO EDUCATION</span>
          </h1>

          <p className="text-lg md:text-xl text-muted-foreground font-medium text-balance max-w-2xl mx-auto leading-relaxed">
            Get matched with scholarships, programs, and communities designed for students with experiences like yours.
          </p>
          
          <div className="flex flex-wrap items-center justify-center gap-6 mt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span>No standardized tests required</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span>First-generation friendly</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span>Multilingual support</span>
            </div>
          </div>
        </div>

        {/* CTA Button */}
        <div className="mb-16">
          <Link href="/survey">
            <Button size="lg" className="text-lg px-8 py-6 rounded-full font-semibold group">
              Get Your Inclusivity Index
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
          <p className="text-sm text-muted-foreground mt-4">Takes just 2 minutes • Completely free</p>
        </div>

        {/* Feature Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="bg-card border border-border rounded-2xl p-6 text-left hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
              <Award className="h-6 w-6 text-accent" />
            </div>
            <h3 className="text-lg font-semibold mb-2 text-card-foreground">Scholarships</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Discover funding opportunities that don't require standardized tests and support first-generation
              students.
            </p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 text-left hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
              <Globe className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2 text-card-foreground">Programs</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Access STEM camps, enrichment programs, and initiatives designed for neurodiverse learners.
            </p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 text-left hover:shadow-lg transition-shadow">
            <div className="w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center mb-4">
              <Users className="h-6 w-6 text-accent" />
            </div>
            <h3 className="text-lg font-semibold mb-2 text-card-foreground">Communities</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Connect with local organizations, mentorship networks, and peer support groups.
            </p>
          </div>
        </div>
      </div>
    </section>

    {/* Trust Indicators */}
    <section className="py-12 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap items-center justify-center gap-8 opacity-60">
          <div className="flex items-center gap-2 text-sm font-medium">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <span>Research-Based Matching</span>
          </div>
          <div className="flex items-center gap-2 text-sm font-medium">
            <Heart className="h-4 w-4 text-red-500" />
            <span>100% Free</span>
          </div>
          <div className="flex items-center gap-2 text-sm font-medium">
            <Users className="h-4 w-4 text-blue-600" />
            <span>Inclusive by Design</span>
          </div>
          <div className="flex items-center gap-2 text-sm font-medium">
            <Award className="h-4 w-4 text-purple-600" />
            <span>Curated Opportunities</span>
          </div>
        </div>
      </div>
    </section>

    {/* How It Works */}
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            🚀 Simple Process
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">How Pathways Works</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Get personalized scholarship matches in three simple steps
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center group">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-primary/70 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <span className="text-2xl font-black text-primary-foreground">1</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">Take Our Survey</h3>
            <p className="text-muted-foreground leading-relaxed">
              Answer 10 quick questions about your background, goals, and challenges. Takes just 2 minutes.
            </p>
          </div>

          <div className="text-center group">
            <div className="w-16 h-16 bg-gradient-to-br from-accent to-accent/70 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <span className="text-2xl font-black text-accent-foreground">2</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">Get Your Index</h3>
            <p className="text-muted-foreground leading-relaxed">
              Receive your personalized Inclusivity Index and see which barriers you face in accessing education.
            </p>
          </div>

          <div className="text-center group">
            <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-400 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
              <span className="text-2xl font-black text-white">3</span>
            </div>
            <h3 className="text-xl font-semibold mb-3">Find Opportunities</h3>
            <p className="text-muted-foreground leading-relaxed">
              Discover scholarships, programs, and communities specifically designed for students like you.
            </p>
          </div>
        </div>
      </div>
    </section>

    {/* FAQ Section */}
    <section className="py-20 bg-muted/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            ❓ Frequently Asked Questions
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Got Questions? We've Got Answers</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about Pathways and how we help you find educational opportunities
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="item-1" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">What is the Inclusivity Index and how is it calculated?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                The Inclusivity Index is a personalized score (0-100) that measures the barriers you face in accessing educational opportunities. It's calculated based on factors like family income, technology access, language support, learning differences, and academic background. A higher score means you face more barriers and qualify for more targeted support programs and scholarships designed for students with similar challenges.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-2" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">Is Pathways really completely free to use?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                Yes, Pathways is 100% free for students. We believe that cost should never be a barrier to accessing educational opportunities. Our platform is supported by partnerships with educational organizations and foundations who share our mission of making education more accessible and inclusive.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-3" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">How do you find scholarships that don't require standardized tests?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                We specifically curate opportunities from organizations that recognize standardized tests can be barriers for many students. Our database includes scholarships that focus on essays, community involvement, personal stories, financial need, and other holistic criteria. We also partner with test-optional colleges and programs that value diverse forms of achievement.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-4" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">What makes Pathways different from other scholarship search platforms?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                Unlike traditional platforms that focus on academic achievements, Pathways is designed with equity and inclusion at its core. We understand that students face different barriers and match you with opportunities specifically created for your circumstances. We also go beyond scholarships to include enrichment programs, mentorship opportunities, and community resources.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-5" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">How do you protect my personal information?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                We take your privacy seriously. Your personal information is encrypted and stored securely. We never sell your data to third parties. We only share anonymized, aggregated data with our partner organizations to help them better understand the needs of students like you. You have full control over your data and can delete your account at any time.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-6" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">Can international students or DACA recipients use Pathways?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                Absolutely! We specifically include scholarships and programs that are open to international students, DACA recipients, and undocumented students. Our survey includes questions about your citizenship status to ensure we only show you opportunities you're eligible for. We believe education should be accessible regardless of immigration status.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-7" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">What if I'm not sure about my career goals yet?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                That's completely normal! Many of our opportunities don't require you to have a specific major or career path in mind. We include general scholarships, exploratory programs, and opportunities specifically designed for students who are still discovering their interests. The survey allows you to indicate if you're undecided, and we'll match you accordingly.
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="item-8" className="bg-background border rounded-lg px-6">
              <AccordionTrigger className="text-left hover:no-underline py-6">
                <span className="font-semibold">How often should I check back for new opportunities?</span>
              </AccordionTrigger>
              <AccordionContent className="pb-6 text-muted-foreground leading-relaxed">
                We're constantly adding new scholarships and programs to our database. We recommend checking back monthly, especially during peak application seasons (fall and spring). In the future, we plan to add email notifications to alert you when new opportunities that match your profile become available.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </section>

    {/* Final CTA Section */}
    <section className="py-20 bg-gradient-to-br from-background to-muted/30">
      <div className="container mx-auto px-4 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-accent/10 text-accent text-sm font-medium mb-6">
            🎯 Ready to Start?
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Your Educational Journey Starts Here
          </h2>
          <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
            Join thousands of students who've found their path to educational success. 
            Take our quick survey and discover opportunities designed specifically for you.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Link href="/survey">
              <Button size="lg" className="text-lg px-8 py-6 rounded-full font-semibold group">
                Start Your Journey
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 rounded-full font-semibold group bg-transparent">
              <Play className="mr-2 h-5 w-5" />
              Watch How It Works
            </Button>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>100% Free Forever</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Takes Only 2 Minutes</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <span>Instant Results</span>
            </div>
          </div>
        </div>
      </div>
    </section>
    </>
  )
}
