"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, ArrowRight, BookOpen, Heart, Lightbulb, MapPin, DollarSign, Users, Target, GraduationCap } from "lucide-react"
import { useRouter } from "next/navigation"

interface SurveyData {
  // Basic Demographics & Barriers
  incomeLevel: string
  deviceAccess: string
  internetAccess: string
  languageSupport: string
  learningNeeds: string
  location: string
  educationLevel: string
  
  // Academic Profile
  favoriteSubject: string
  difficultClass: string
  academicProject: string
  testScoreReflection: string
  dreamCourse: string
  gpaRange: string
  hasTestScores: string
  satScore: string
  actScore: string
  testScorePreference: string
  
  // Personal & Activities
  freeTimeActivities: string
  mostMeaningfulActivity: string
  summerActivities: string
  leadershipExperience: string
  workExperience: string
  
  // Future Vision & Motivation
  whyCollege: string
  worldProblems: string
  futureVision: string
  potentialMajor: string
  roleModel: string
  
  // Practical Preferences
  geographyPreference: string
  schoolSizePreference: string
  budgetReality: string
  nonNegotiables: string
  
  // Open-ended
  barriers: string
  goals: string
}

interface Question {
  id: string
  title: string
  type: "radio" | "input" | "textarea"
  options?: { value: string; label: string }[]
  placeholder?: string
  conditional?: string
  conditionalValue?: string
}

interface QuestionSection {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  questions: Question[]
}

const questionSections: QuestionSection[] = [
  {
    id: "demographics",
    title: "Your Background",
    description: "Help us understand your unique circumstances",
    icon: <Users className="h-5 w-5" />,
    questions: [
      {
        id: "incomeLevel",
        title: "What best describes your family's income level?",
        type: "radio",
        options: [
          { value: "low", label: "Low income (qualify for free/reduced lunch)" },
          { value: "moderate", label: "Moderate income" },
          { value: "middle", label: "Middle income" },
          { value: "prefer-not-to-say", label: "Prefer not to say" },
        ],
      },
      {
        id: "deviceAccess",
        title: "What devices do you have reliable access to?",
        type: "radio",
        options: [
          { value: "smartphone-only", label: "Smartphone only" },
          { value: "smartphone-tablet", label: "Smartphone and tablet" },
          { value: "smartphone-computer", label: "Smartphone and computer/laptop" },
          { value: "all-devices", label: "All devices (smartphone, tablet, computer)" },
        ],
      },
      {
        id: "internetAccess",
        title: "How would you describe your internet access?",
        type: "radio",
        options: [
          { value: "limited", label: "Limited or unreliable" },
          { value: "mobile-only", label: "Mobile data only" },
          { value: "home-wifi", label: "Reliable home WiFi" },
          { value: "multiple-locations", label: "Access at home, school, and other locations" },
        ],
      },
      {
        id: "languageSupport",
        title: "What is your primary language situation?",
        type: "radio",
        options: [
          { value: "english-first", label: "English is my first language" },
          { value: "english-second", label: "English is my second language" },
          { value: "multilingual", label: "I'm multilingual" },
          { value: "need-translation", label: "I often need translation support" },
        ],
      },
      {
        id: "learningNeeds",
        title: "Do you have any learning differences or accessibility needs?",
        type: "radio",
        options: [
          { value: "none", label: "No specific needs" },
          { value: "adhd", label: "ADHD or attention differences" },
          { value: "dyslexia", label: "Dyslexia or reading differences" },
          { value: "other", label: "Other learning differences" },
          { value: "prefer-not-to-say", label: "Prefer not to say" },
        ],
      },
      {
        id: "location",
        title: "Where are you located?",
        type: "input",
        placeholder: "City, State or Country",
      },
      {
        id: "educationLevel",
        title: "What is your current education level?",
        type: "radio",
        options: [
          { value: "high-school", label: "High school student" },
          { value: "community-college", label: "Community college student" },
          { value: "undergraduate", label: "Undergraduate student" },
          { value: "graduate", label: "Graduate student" },
          { value: "other", label: "Other" },
        ],
      },
    ],
  },
  {
    id: "academics",
    title: "Your Academic Journey",
    description: "Tell us about your intellectual interests and challenges",
    icon: <BookOpen className="h-5 w-5" />,
    questions: [
      {
        id: "favoriteSubject",
        title: "What was your favorite class and why? (Not necessarily the one you got the best grade in)",
        type: "textarea",
        placeholder: "Tell us about a subject that genuinely excited you to learn...",
      },
      {
        id: "difficultClass",
        title: "What was the most difficult class you took? What did you do when you struggled?",
        type: "textarea",
        placeholder: "Describe the challenge and how you responded...",
      },
      {
        id: "academicProject",
        title: "What academic project or paper are you most proud of? Tell us about the process.",
        type: "textarea",
        placeholder: "What rabbit hole did you go down? What did you discover?",
      },
      {
        id: "gpaRange",
        title: "What is your current GPA range?",
        type: "radio",
        options: [
          { value: "3.5-4.0", label: "3.5 - 4.0" },
          { value: "3.0-3.4", label: "3.0 - 3.4" },
          { value: "2.5-2.9", label: "2.5 - 2.9" },
          { value: "below-2.5", label: "Below 2.5" },
          { value: "not-applicable", label: "Not applicable/Don't know" },
        ],
      },
      {
        id: "hasTestScores",
        title: "Have you taken standardized tests (SAT/ACT) and would you like to use these scores for scholarship matching?",
        type: "radio",
        options: [
          { value: "yes-use-scores", label: "Yes, I have scores and want to use them" },
          { value: "yes-no-use", label: "Yes, I have scores but prefer not to use them" },
          { value: "no-scores", label: "No, I haven't taken these tests" },
          { value: "planning-to-take", label: "I'm planning to take them" },
        ],
      },
      {
        id: "satScore",
        title: "What is your highest SAT score? (Optional - only if you selected to use scores)",
        type: "input",
        placeholder: "e.g., 1450 (leave blank if you took ACT instead)",
        conditional: "hasTestScores",
        conditionalValue: "yes-use-scores",
      },
      {
        id: "actScore",
        title: "What is your highest ACT score? (Optional - only if you selected to use scores)",
        type: "input",
        placeholder: "e.g., 32 (leave blank if you took SAT instead)",
        conditional: "hasTestScores",
        conditionalValue: "yes-use-scores",
      },
      {
        id: "testScorePreference",
        title: "How would you like us to use your test scores in matching?",
        type: "radio",
        options: [
          { value: "expand-opportunities", label: "Show me ALL opportunities (test-optional AND test-required)" },
          { value: "merit-focus", label: "Focus on merit-based scholarships that value high scores" },
          { value: "balanced-approach", label: "Balanced mix of both types of opportunities" },
        ],
        conditional: "hasTestScores",
        conditionalValue: "yes-use-scores",
      },
      {
        id: "testScoreReflection",
        title: "Do you feel standardized test scores accurately represent your academic ability? Why or why not?",
        type: "textarea",
        placeholder: "Share your thoughts on standardized testing...",
      },
      {
        id: "dreamCourse",
        title: "If you could design your own course, what would it be about?",
        type: "textarea",
        placeholder: "What would you teach? What would students learn?",
      },
    ],
  },
  {
    id: "activities",
    title: "Beyond the Classroom",
    description: "What do you bring to your community?",
    icon: <Heart className="h-5 w-5" />,
    questions: [
      {
        id: "freeTimeActivities",
        title: "What do you do with your free time? Tell us what you've actually accomplished.",
        type: "textarea",
        placeholder: "Don't just list clubs - tell us what you built, organized, or solved...",
      },
      {
        id: "mostMeaningfulActivity",
        title: "Which of your activities means the most to you? If you could only continue one in college, which would it be and why?",
        type: "textarea",
        placeholder: "What activity shows your passion and commitment?",
      },
      {
        id: "summerActivities",
        title: "How have you spent your last two summers? ☀️",
        type: "textarea",
        placeholder: "What did you do with this unstructured time?",
      },
      {
        id: "leadershipExperience",
        title: "Tell us about a time you led something (formal or informal leadership counts).",
        type: "textarea",
        placeholder: "Group project, organizing friends, taking charge in family situations...",
      },
      {
        id: "workExperience",
        title: "Have you had a job? What did you learn about the world and about yourself?",
        type: "textarea",
        placeholder: "Mowing lawns, babysitting, retail - it all counts and teaches valuable lessons...",
      },
    ],
  },
  {
    id: "future",
    title: "Your Vision & Motivation",
    description: "Connect who you are now with who you want to become",
    icon: <Target className="h-5 w-5" />,
    questions: [
      {
        id: "whyCollege",
        title: "Why college? What do you believe you will get from a college education that you can't get anywhere else?",
        type: "textarea",
        placeholder: "Be honest about your motivation for higher education...",
      },
      {
        id: "worldProblems",
        title: "What problems in the world fire you up? What injustices or challenges make you want to do something? 🌎",
        type: "textarea",
        placeholder: "What issues keep you up at night or motivate you to act?",
      },
      {
        id: "futureVision",
        title: "Imagine you're 25. What does a happy, successful day look like for you?",
        type: "textarea",
        placeholder: "Not just a job title - what kind of life do you want to live?",
      },
      {
        id: "potentialMajor",
        title: "If you had to choose a potential major right now, what's your best guess? What's a 'wild card' major you'd consider?",
        type: "textarea",
        placeholder: "Best guess and a fun alternative you might explore...",
      },
      {
        id: "roleModel",
        title: "Who is a role model for you? What specific qualities do you admire in that person?",
        type: "textarea",
        placeholder: "Tell us about someone who inspires you and why...",
      },
    ],
  },
  {
    id: "practical",
    title: "Practical Realities",
    description: "Let's ground your dreams in reality",
    icon: <MapPin className="h-5 w-5" />,
    questions: [
      {
        id: "geographyPreference",
        title: "Do you see yourself in a bustling city, quiet college town, or somewhere in between? Close to home or far away?",
        type: "textarea",
        placeholder: "Describe your ideal location and distance from family...",
      },
      {
        id: "schoolSizePreference",
        title: "When you picture yourself on campus, are you in a massive lecture hall with 300 students or a small seminar with 15?",
        type: "radio",
        options: [
          { value: "large", label: "Large university (15,000+ students)" },
          { value: "medium", label: "Medium university (5,000-15,000 students)" },
          { value: "small", label: "Small college (under 5,000 students)" },
          { value: "no-preference", label: "No strong preference" },
        ],
      },
      {
        id: "budgetReality",
        title: "What is your family's realistic budget for college? 💰 (We need to be honest about finances)",
        type: "radio",
        options: [
          { value: "need-full-aid", label: "Need full financial aid/scholarships" },
          { value: "under-10k", label: "Under $10,000 per year" },
          { value: "10k-25k", label: "$10,000 - $25,000 per year" },
          { value: "25k-50k", label: "$25,000 - $50,000 per year" },
          { value: "over-50k", label: "Over $50,000 per year" },
          { value: "prefer-not-to-say", label: "Prefer not to say" },
        ],
      },
      {
        id: "nonNegotiables",
        title: "What are the 'non-negotiables' for you and your family? (Specific programs, religious affiliation, distance, etc.)",
        type: "textarea",
        placeholder: "Must-haves or deal-breakers for your college choice...",
      },
    ],
  },
  {
    id: "reflection",
    title: "Final Reflections",
    description: "Help us understand your complete story",
    icon: <Lightbulb className="h-5 w-5" />,
    questions: [
      {
        id: "barriers",
        title: "What barriers have you faced in accessing educational opportunities?",
        type: "textarea",
        placeholder: "Share any challenges you've experienced (optional but helpful for matching)...",
      },
      {
        id: "goals",
        title: "What are your educational and career goals? What do you hope to achieve?",
        type: "textarea",
        placeholder: "Tell us about your aspirations and dreams...",
      },
    ],
  },
]

export function EnhancedSurveyForm() {
  const [currentSectionIndex, setCurrentSectionIndex] = useState(0)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [surveyData, setSurveyData] = useState<Partial<SurveyData>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const router = useRouter()

  const currentSection = questionSections[currentSectionIndex]
  const allQuestions = currentSection.questions
  
  // Filter questions based on conditional logic
  const visibleQuestions = allQuestions.filter(question => {
    if (!question.conditional) return true
    const conditionalValue = surveyData[question.conditional as keyof SurveyData]
    return conditionalValue === question.conditionalValue
  })
  
  const currentQuestion = visibleQuestions[currentQuestionIndex]
  // Calculate total visible questions dynamically
  const getTotalVisibleQuestions = () => {
    return questionSections.reduce((sum, section) => {
      const visibleInSection = section.questions.filter(question => {
        if (!question.conditional) return true
        const conditionalValue = surveyData[question.conditional as keyof SurveyData]
        return conditionalValue === question.conditionalValue
      }).length
      return sum + visibleInSection
    }, 0)
  }

  const getCompletedQuestions = () => {
    let completed = 0
    for (let i = 0; i < currentSectionIndex; i++) {
      const visibleInSection = questionSections[i].questions.filter(question => {
        if (!question.conditional) return true
        const conditionalValue = surveyData[question.conditional as keyof SurveyData]
        return conditionalValue === question.conditionalValue
      }).length
      completed += visibleInSection
    }
    return completed + currentQuestionIndex
  }

  const totalQuestions = getTotalVisibleQuestions()
  const completedQuestions = getCompletedQuestions()
  const progress = totalQuestions > 0 ? ((completedQuestions + 1) / totalQuestions) * 100 : 0

  const handleAnswer = (questionId: string, value: string) => {
    setSurveyData((prev) => ({
      ...prev,
      [questionId]: value,
    }))
  }

  const handleNext = () => {
    const isLastQuestionInSection = currentQuestionIndex === visibleQuestions.length - 1
    const isLastSection = currentSectionIndex === questionSections.length - 1

    if (isLastQuestionInSection && isLastSection) {
      handleSubmit()
    } else if (isLastQuestionInSection) {
      setCurrentSectionIndex(currentSectionIndex + 1)
      setCurrentQuestionIndex(0)
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex === 0 && currentSectionIndex === 0) return

    if (currentQuestionIndex === 0) {
      const prevSectionIndex = currentSectionIndex - 1
      setCurrentSectionIndex(prevSectionIndex)
      // Get visible questions for previous section
      const prevSectionQuestions = questionSections[prevSectionIndex].questions.filter(question => {
        if (!question.conditional) return true
        const conditionalValue = surveyData[question.conditional as keyof SurveyData]
        return conditionalValue === question.conditionalValue
      })
      setCurrentQuestionIndex(prevSectionQuestions.length - 1)
    } else {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)

    // Enhanced Inclusivity Index calculation with deeper understanding
    const calculateEnhancedInclusivityIndex = (data: Partial<SurveyData>) => {
      let score = 0
      let maxScore = 0

      // Demographic barriers (40% of score)
      maxScore += 40
      if (data.incomeLevel === "low") score += 15
      else if (data.incomeLevel === "moderate") score += 10
      else if (data.incomeLevel === "middle") score += 5

      if (data.deviceAccess === "smartphone-only") score += 10
      else if (data.deviceAccess === "smartphone-tablet") score += 7
      else if (data.deviceAccess === "smartphone-computer") score += 5

      if (data.internetAccess === "limited") score += 10
      else if (data.internetAccess === "mobile-only") score += 7

      if (data.languageSupport === "need-translation") score += 5
      else if (data.languageSupport === "english-second") score += 3

      // Academic challenges (25% of score)
      maxScore += 25
      if (data.learningNeeds === "adhd" || data.learningNeeds === "dyslexia" || data.learningNeeds === "other") {
        score += 10
      }

      // GPA considerations
      if (data.gpaRange === "below-2.5") score += 8
      else if (data.gpaRange === "2.5-2.9") score += 5
      else if (data.gpaRange === "3.0-3.4") score += 2

      // Test score situation analysis
      if (data.hasTestScores === "no-scores" || data.hasTestScores === "yes-no-use") {
        score += 5 // Students without/not using test scores face more barriers
      }

      // Test score reflection analysis
      if (data.testScoreReflection?.toLowerCase().includes("don't reflect") || 
          data.testScoreReflection?.toLowerCase().includes("not accurate")) {
        score += 2
      }

      // Barriers mentioned
      if (data.barriers && data.barriers.length > 50) {
        score += 5
      }

      // Financial reality (20% of score)
      maxScore += 20
      if (data.budgetReality === "need-full-aid") score += 20
      else if (data.budgetReality === "under-10k") score += 15
      else if (data.budgetReality === "10k-25k") score += 10

      // Geographic/social factors (15% of score)
      maxScore += 15
      if (data.location?.toLowerCase().includes("rural") || 
          data.geographyPreference?.toLowerCase().includes("rural")) {
        score += 8
      }

      if (data.workExperience && data.workExperience.length > 20) {
        score += 7 // Work experience often indicates financial need
      }

      return Math.min(Math.round((score / maxScore) * 100), 100)
    }

    const inclusivityIndex = calculateEnhancedInclusivityIndex(surveyData)

    // Store comprehensive results
    localStorage.setItem(
      "surveyResults",
      JSON.stringify({
        ...surveyData,
        inclusivityIndex,
        completedAt: new Date().toISOString(),
        surveyVersion: "enhanced-v1",
      }),
    )

    router.push("/dashboard")
  }

  const isLastQuestion = currentSectionIndex === questionSections.length - 1 && 
                       currentQuestionIndex === visibleQuestions.length - 1
  const canProceed = surveyData[currentQuestion.id as keyof SurveyData] || currentQuestion.type === "textarea"

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-3xl">
        {/* Progress Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                {currentSection.icon}
              </div>
              <div>
                <h2 className="font-semibold text-lg">{currentSection.title}</h2>
                <p className="text-sm text-muted-foreground">{currentSection.description}</p>
              </div>
            </div>
            <Badge variant="secondary">
              {completedQuestions + 1} of {totalQuestions}
            </Badge>
          </div>
          
            <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Question {currentQuestionIndex + 1} of {visibleQuestions.length} in this section</span>
              <span>{Math.round(progress)}% complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </div>

        {/* Question Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl text-balance leading-relaxed">{currentQuestion.title}</CardTitle>
            {currentSectionIndex === 0 && currentQuestionIndex === 0 && (
              <CardDescription>
                This comprehensive survey helps us understand your unique situation and find the best opportunities for you. 
                Be honest - this information is used only to match you with relevant scholarships and programs.
              </CardDescription>
            )}
          </CardHeader>
          <CardContent className="space-y-4">
            {currentQuestion.type === "radio" && currentQuestion.options && (
              <RadioGroup
                value={surveyData[currentQuestion.id as keyof SurveyData] || ""}
                onValueChange={(value) => handleAnswer(currentQuestion.id, value)}
              >
                {currentQuestion.options.map((option) => (
                  <div key={option.value} className="flex items-start space-x-3">
                    <RadioGroupItem value={option.value} id={option.value} className="mt-1" />
                    <Label htmlFor={option.value} className="text-sm leading-relaxed cursor-pointer flex-1">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            )}

            {currentQuestion.type === "input" && (
              <Input
                placeholder={currentQuestion.placeholder}
                value={surveyData[currentQuestion.id as keyof SurveyData] || ""}
                onChange={(e) => handleAnswer(currentQuestion.id, e.target.value)}
                className="text-base"
              />
            )}

            {currentQuestion.type === "textarea" && (
              <Textarea
                placeholder={currentQuestion.placeholder}
                value={surveyData[currentQuestion.id as keyof SurveyData] || ""}
                onChange={(e) => handleAnswer(currentQuestion.id, e.target.value)}
                className="min-h-32 text-base leading-relaxed"
              />
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentSectionIndex === 0 && currentQuestionIndex === 0}
            className="flex items-center gap-2 bg-transparent"
          >
            <ArrowLeft className="h-4 w-4" />
            Previous
          </Button>

          <Button
            onClick={handleNext}
            disabled={!canProceed && currentQuestion.type !== "textarea"}
            className="flex items-center gap-2"
          >
            {isLastQuestion ? (
              isSubmitting ? (
                "Creating Your Profile..."
              ) : (
                <>
                  <GraduationCap className="h-4 w-4" />
                  Get My Matches
                </>
              )
            ) : (
              <>
                Next
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
