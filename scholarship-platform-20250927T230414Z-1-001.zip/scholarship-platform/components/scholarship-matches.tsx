"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, ExternalLink, Search, Filter, Calendar, DollarSign } from "lucide-react"

interface Scholarship {
  id: string
  title: string
  organization: string
  amount: string
  deadline: string
  description: string
  eligibility: string[]
  type: "need-based" | "merit-based" | "first-gen" | "stem" | "international" | "test-optional"
  matchScore: number
  saved: boolean
  requiresTestScores?: boolean
  minSAT?: number
  minACT?: number
  testOptional?: boolean
}

// Mock scholarship data
const scholarships: Scholarship[] = [
  {
    id: "1",
    title: "First Generation College Student Scholarship",
    organization: "Education Foundation",
    amount: "$5,000",
    deadline: "March 15, 2025",
    description: "Supporting first-generation college students who demonstrate financial need and academic potential.",
    eligibility: ["First-generation college student", "Financial need", "3.0+ GPA"],
    type: "first-gen",
    matchScore: 95,
    saved: false,
    testOptional: true,
  },
  {
    id: "2",
    title: "STEM Diversity Scholarship",
    organization: "Tech for All Foundation",
    amount: "$7,500",
    deadline: "April 1, 2025",
    description: "Empowering underrepresented students pursuing STEM degrees with financial support and mentorship.",
    eligibility: ["STEM major", "Underrepresented minority", "Community college transfer"],
    type: "stem",
    matchScore: 88,
    saved: false,
    testOptional: true,
  },
  {
    id: "3",
    title: "English Language Learner Achievement Award",
    organization: "Multilingual Education Alliance",
    amount: "$3,000",
    deadline: "February 28, 2025",
    description: "Recognizing academic excellence among students for whom English is a second language.",
    eligibility: ["English as second language", "Academic achievement", "Community involvement"],
    type: "need-based",
    matchScore: 82,
    saved: false,
    testOptional: true,
  },
  {
    id: "4",
    title: "Neurodiversity in Education Scholarship",
    organization: "Learning Differences Foundation",
    amount: "$4,000",
    deadline: "May 15, 2025",
    description: "Supporting students with learning differences who have shown resilience and determination.",
    eligibility: ["Learning differences", "Self-advocacy", "Academic progress"],
    type: "need-based",
    matchScore: 78,
    saved: false,
    testOptional: true,
  },
  {
    id: "5",
    title: "Rural Student Success Grant",
    organization: "Rural Education Initiative",
    amount: "$2,500",
    deadline: "March 30, 2025",
    description: "Helping rural students access higher education opportunities and overcome geographic barriers.",
    eligibility: ["Rural location", "Limited resources", "College-bound"],
    type: "need-based",
    matchScore: 75,
    saved: false,
    testOptional: true,
  },
  {
    id: "6",
    title: "National Merit Excellence Scholarship",
    organization: "Academic Excellence Foundation",
    amount: "$15,000",
    deadline: "January 15, 2025",
    description: "Recognizing outstanding academic achievement through standardized test performance and GPA.",
    eligibility: ["SAT 1450+ or ACT 32+", "3.8+ GPA", "Leadership experience"],
    type: "merit-based",
    matchScore: 85,
    saved: false,
    requiresTestScores: true,
    minSAT: 1450,
    minACT: 32,
  },
  {
    id: "7",
    title: "STEM Academic Achievement Award",
    organization: "National Science Foundation",
    amount: "$10,000",
    deadline: "February 1, 2025",
    description: "Supporting high-achieving STEM students with demonstrated academic excellence in mathematics and science.",
    eligibility: ["STEM major", "SAT Math 750+ or ACT Math 34+", "3.7+ GPA"],
    type: "merit-based",
    matchScore: 80,
    saved: false,
    requiresTestScores: true,
    minSAT: 1400,
    minACT: 30,
  },
  {
    id: "8",
    title: "Presidential Scholars Program",
    organization: "University Excellence Initiative",
    amount: "$20,000",
    deadline: "December 1, 2024",
    description: "Full merit scholarship for exceptional students demonstrating academic excellence and leadership potential.",
    eligibility: ["SAT 1500+ or ACT 34+", "4.0 GPA", "Extensive leadership", "Community service"],
    type: "merit-based",
    matchScore: 90,
    saved: false,
    requiresTestScores: true,
    minSAT: 1500,
    minACT: 34,
  },
  {
    id: "9",
    title: "Test-Optional Community Leaders Scholarship",
    organization: "Inclusive Education Alliance",
    amount: "$6,000",
    deadline: "April 15, 2025",
    description: "Celebrating students who have made significant community impact, regardless of test scores.",
    eligibility: ["Community leadership", "Volunteer service 100+ hours", "Personal essay"],
    type: "test-optional",
    matchScore: 88,
    saved: false,
    testOptional: true,
  },
  {
    id: "10",
    title: "Holistic Achievement Scholarship",
    organization: "Whole Student Foundation",
    amount: "$8,000",
    deadline: "March 1, 2025",
    description: "Recognizing students who excel through diverse talents and experiences beyond standardized testing.",
    eligibility: ["Portfolio submission", "Creative or artistic achievement", "Overcoming challenges"],
    type: "test-optional",
    matchScore: 83,
    saved: false,
    testOptional: true,
  },
]

interface ScholarshipMatchesProps {
  onSave: (scholarshipId: string) => void
}

export function ScholarshipMatches({ onSave }: ScholarshipMatchesProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [savedScholarships, setSavedScholarships] = useState<Set<string>>(new Set())

  const filteredScholarships = scholarships.filter((scholarship) => {
    const matchesSearch =
      scholarship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scholarship.organization.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterType === "all" || scholarship.type === filterType
    return matchesSearch && matchesFilter
  })

  const handleSave = (scholarshipId: string) => {
    const newSaved = new Set(savedScholarships)
    if (newSaved.has(scholarshipId)) {
      newSaved.delete(scholarshipId)
    } else {
      newSaved.add(scholarshipId)
    }
    setSavedScholarships(newSaved)
    onSave(scholarshipId)
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case "need-based":
        return "bg-blue-100 text-blue-800"
      case "merit-based":
        return "bg-green-100 text-green-800"
      case "first-gen":
        return "bg-purple-100 text-purple-800"
      case "stem":
        return "bg-orange-100 text-orange-800"
      case "international":
        return "bg-pink-100 text-pink-800"
      case "test-optional":
        return "bg-teal-100 text-teal-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Your Scholarship Matches</h2>
          <p className="text-muted-foreground">Ranked by relevance to your profile</p>
        </div>
        <Badge variant="secondary" className="text-sm">
          {filteredScholarships.length} opportunities found
        </Badge>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search scholarships..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="need-based">Need-Based</SelectItem>
            <SelectItem value="merit-based">Merit-Based</SelectItem>
            <SelectItem value="test-optional">Test-Optional</SelectItem>
            <SelectItem value="first-gen">First-Generation</SelectItem>
            <SelectItem value="stem">STEM</SelectItem>
            <SelectItem value="international">International</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Scholarship Cards */}
      <div className="grid gap-6">
        {filteredScholarships.map((scholarship) => (
          <Card key={scholarship.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="text-xs font-semibold">
                      {scholarship.matchScore}% match
                    </Badge>
                    <Badge className={`text-xs ${getTypeColor(scholarship.type)}`}>
                      {scholarship.type.replace("-", " ")}
                    </Badge>
                  </div>
                  <CardTitle className="text-xl text-balance leading-tight">{scholarship.title}</CardTitle>
                  <CardDescription className="text-base">{scholarship.organization}</CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => handleSave(scholarship.id)} className="shrink-0">
                  <Heart
                    className={`h-4 w-4 ${
                      savedScholarships.has(scholarship.id) ? "fill-red-500 text-red-500" : "text-muted-foreground"
                    }`}
                  />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground leading-relaxed">{scholarship.description}</p>

              <div className="flex flex-wrap gap-2">
                {scholarship.eligibility.map((criteria, index) => (
                  <Badge key={index} variant="secondary" className="text-xs">
                    {criteria}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center justify-between pt-4 border-t">
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <DollarSign className="h-4 w-4" />
                    <span className="font-medium">{scholarship.amount}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>Due {scholarship.deadline}</span>
                  </div>
                </div>
                <Button size="sm" className="gap-2">
                  Apply Now
                  <ExternalLink className="h-3 w-3" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
